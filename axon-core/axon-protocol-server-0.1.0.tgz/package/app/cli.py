import argparse
import sys
import uvicorn
import os

def main():
    parser = argparse.ArgumentParser(description="Axon Protocol Server CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    dev_parser = subparsers.add_parser("dev", help="Start Axon server in local mode")
    dev_parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    dev_parser.add_argument("--port", type=int, default=8000, help="Port to bind (default: 8000)")
    
    args = parser.parse_args()
    
    if args.command == "dev":
        # Force local mode
        os.environ["AXON_MODE"] = "local"
        
        # Ensure directory exists
        axon_dir = os.path.expanduser("~/.axon")
        os.makedirs(axon_dir, exist_ok=True)
        
        print(f"Starting Axon server in local mode on http://{args.host}:{args.port}...")
        uvicorn.run("app.main:app", host=args.host, port=args.port, reload=False)
    else:
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
